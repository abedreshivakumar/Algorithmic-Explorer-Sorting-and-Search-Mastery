package Base;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.Scanner;

public class CS401prj {

	@SuppressWarnings("unused")
	public static void main(String[] args) throws InterruptedException, IOException {
		
		System.out.println("Sorting and Searching : ");
		
		Scanner sc = new Scanner(System.in);
		String option = null;
		String dataType = null;
		String element;
		int searchIndex;
		
		String[] array = null;
		array = dataEntry();
		
		do {
	
			System.out.println("MENU:");//menu for sorting and selection
			System.out.println("     ");
			System.out.println("CHOOSE FUNCTION FROM THE BELOW LIST: ");
			System.out.println("     ");
			System.out.println("1) Selection Sort");
			System.out.println("2) Heap Sort");
			System.out.println("3) Linear Search");
			System.out.println("4) Binary Search Tree");
			System.out.println("5) Hash function search");
			System.out.println("6) Exit"); 
			System.out.println("      ");
			System.out.println("Enter the number: ");
			option = sc.nextLine();
			int comparisions = 0;
			
			if(option.equals("1")) {
					String[] selectionArray = array.clone();
					comparisions = Sorting.selectionSort(selectionArray);
					System.out.println("Sorting done !");
					printData(selectionArray);
					System.out.println("Number of comparisons using Selection Sort = " + comparisions);
					option = "0";
			}
			
			else if(option.equals("2")) {
				String[] heapArray = array.clone();
				comparisions = Sorting.heapSort(heapArray);
				System.out.println("Sorting done !");
				printData(heapArray);
				System.out.println("Number of comparisons using Heap Sort = " + comparisions);
				option = "0";
			}
			else if(option.equals("3")) {
				System.out.println("Enter the element you want to linear search for:");
				element = sc.nextLine();
				searchIndex = Searching.linearSearch(array, element);
				option = "0";
			}
			else if(option.equals("4")) {
				System.out.println("Enter the element you want to binary search for:");
				element = sc.nextLine();
				boolean found = Searching.bstSearch(array, element);
				option = "0";
			}
			else if(option.equals("5")) {
				System.out.println("Enter the element you want to Hash function search for:");
				element = sc.nextLine();
				Searching.hashSearch(array, element);
				option = "0";
			}
		
			else if(option.equals("6")) {
				System.out.println("Exit");
			}
			
			else
				System.out.println("Enter the number from the list !\n");
			
		}while(!(option.equals("1") || option.equals("2") || option.equals("3") || option.equals("4") || option.equals("5") || option.equals("6")));
		
	}	
	
	public static void printData(String[] data) {
		for(int i=0; i<data.length; i=i+10) {
			for(int j=0; j<10 && i+j<data.length; j++) {
				System.out.printf("%10s", data[i+j]);
			}
			System.out.println();
		}
	}
	
	public static String getDataType(String test) {
		if(test.matches("[+-]?[0-9]+"))
			return "int";
		else if(test.matches("[-+]?[0-9]*\\.?[0-9]+"))
			return "float";
		else 
			return "String";
	}
	
	public static int compare(String s1, String s2) {
		if(s1.matches("[+-]?[0-9]+") || s1.matches("[-+]?[0-9]*\\.?[0-9]+")) {
			float f1 = Float.parseFloat(s1);
			float f2 = Float.parseFloat(s2);
			if(f1==f2) return 0;
			else if(f1>f2) return 1;
			else return -1;
		}
		else return s1.compareTo(s2);
	}
	
	public static int lineCounter(File file) throws FileNotFoundException {	
		Scanner lc = new Scanner(file);
		int count = 0;
		while (lc.hasNextLine()) {
		    count++;
		    lc.nextLine();
		}
		lc.close();
		return count;
	}
	
	public static String[] dataEntry() throws FileNotFoundException {
		Scanner input = new Scanner(System.in);
		String entryOption = null;
		int numElements = 0;
		String dataType = null;
		String[] array = null;
		System.out.println("Enter the name of the file preceeded by it's path :");
		String filepath = input.nextLine();
		File file = new File(filepath); 
		array = new String[lineCounter(file)];
		Scanner fileinput = new Scanner(file);
		for(int i=0; i<array.length; i++) {
			array[i] = fileinput.nextLine();
		}
		fileinput.close();



			System.out.println("\nThe file reads :");
			printData(array);
			return array;
		}
	}

