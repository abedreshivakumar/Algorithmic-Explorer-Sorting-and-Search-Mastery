package Base;

import bst.BSTNode;
import bst.BinarySearchTree;
import hash.HMap;

public class Searching {
	
	public static int linearSearch(String[] array, String element) {
		for(int i=0; i<array.length; i++) {
			if(CS401prj.compare(element, array[i]) == 0) {
				System.out.println("The element " + element + " found at index " + i );
				System.out.println("No. of comparisions using Linear Search = " + (i+1) + " \n" );
				return i;
			}
		}
		System.out.println("The element " + element + "not found");
		System.out.println("No. of comparisions using Linear Search = " + array.length + " \n" );
		return -1;
	}
	
	public static boolean bstSearch(String[] data, String element) {
		System.out.println("BST search started!");
		BinarySearchTree<String> tree = new BinarySearchTree<String>();
		String[] sortedData = data.clone();
		tree.setRoot(tree.sortedArrayToBST(sortedData, 0, sortedData.length));
		
		BSTNode<String> node = tree.getRoot();
		int comparisions = 0;
		
		while (node!=null) {
			
			int elementCompare = CS401prj.compare(element, node.getInfo());
			comparisions++;					
			if(elementCompare < 0) {
				node = node.getLeft();
				
			}
			
			else if(elementCompare > 0) {
				node = node.getRight();
			}
			
			else {
				System.out.println("The element " + element + " found");
				System.out.println("No. of comparisions using Binary Search Tree = " + comparisions + " \n" );
				return true;
			}
		}
		System.out.println("The element " + element + " not found");
		System.out.println("No. of comparisions using Binary Search Tree = " + comparisions + " \n" );
		return false;
	}
	
	public static void hashSearch(String[] array, String element) {
		
		HMap<String, String> hash = new HMap<String, String>();
		for (int i = 1; i < array.length; i++) {
			hash.put(array[i], array[i]);
		}
		hash.contains(element);
	}
	
}
