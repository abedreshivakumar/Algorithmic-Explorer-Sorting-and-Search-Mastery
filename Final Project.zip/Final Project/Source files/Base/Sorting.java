package Base;

public class Sorting {
	
	public static int selectionSort(String array[])
    {
        int n = array.length;
        int comparisions = 0;
 
      
        for (int i = 0; i < n-1; i++)
        {
           
            int minIndex = i;
            for (int j = i+1; j < n; j++) {
            	comparisions ++; 
                if (CS401prj.compare(array[j],array[minIndex]) == -1)
                    minIndex = j;
            }
            String temp = array[minIndex];
            array[minIndex] = array[i];
            array[i] = temp;
        }
        return comparisions;
    }
	
	public static int heapSort(String[] array) {
		int index;
		int comparisions1 = 0;
		int comparisions2 = 0;
		for(index = array.length/2 -1; index>=0; index--) {
			comparisions1 = reheapDown(array, index, array.length-1, 0) + comparisions1;
		}
		
		
		for(index=array.length-1; index >=1; index--) {
			swap(array, 0, index);
			comparisions2 = reheapDown(array, 0, index-1, 0) + comparisions2;
		}
		
		
		return comparisions1 + comparisions2;
	}
	
	private static int reheapDown(String[] array, int i, int lastIndex, int comparisions) {
		int largest = i;
		int left = 2*i + 1;
		int right = 2*i + 2;
		
		comparisions++;
		if(left < lastIndex && CS401prj.compare(array[left], array[largest]) > 0) {
			largest = left;
		}
		
		comparisions++;
		if(right < lastIndex && CS401prj.compare(array[right], array[largest]) > 0) {
			largest = right;
		}
		
		if(largest != i) {	
			swap(array, largest, i);
			comparisions = reheapDown(array, largest, lastIndex, comparisions) + comparisions;
		}
		
		
		return comparisions;
	}


    public static void swap(String[] data, int x, int y) {
		String temp = data[x];
		data[x] = data[y];
		data[y] = temp;
	}
}
