package bst;
import java.util.Comparator;



public class BinarySearchTree<T> {

	protected BSTNode<T> root;		
	protected Comparator<T> comp;	
	protected boolean found;		
	
									
	public BinarySearchTree() {		
		root = null;			
		comp = new Comparator<T>() {
			@SuppressWarnings({ "unchecked", "rawtypes" })
			public int compare(T element1, T element2) {
				return ((Comparable)element1).compareTo(element2);
			}
		};
	}
	
	public void setRoot(BSTNode<T> root) {
		this.root = root;
	}
	
	public BSTNode<T> getRoot(){
		return root;
	}
	
	public BinarySearchTree(Comparator<T> comp) {
		root = null;						
		this.comp = comp;
	}	
	
	
	public boolean add(T element) {			
		root = recAdd(element, root);
		return true;
	}

	@SuppressWarnings({ "unchecked", "rawtypes" })
	private BSTNode<T> recAdd(T element, BSTNode<T> node) {		
		if(node == null)												
			node = new BSTNode<T>(element);
		else if(((Comparable) element).compareTo(node.getInfo()) <= 0)	
			node.setLeft(recAdd(element, node.getLeft()));				
		else															
			node.setRight(recAdd(element, node.getRight()));			
		return node;
	}
			

	public boolean contains(T target) {		
		return recContains(target, root);			
	}
	
	private boolean recContains(T target, BSTNode<T> node) {	 
																
		if(node == null)										
			return false;										
		else if(comp.compare(target, node.getInfo()) < 0)		
			return recContains(target, node.getLeft());			
		else if(comp.compare(target, node.getInfo()) > 0)		
			return recContains(target, node.getRight());		
		else
			return true;										
	}
	

	public T get(T target) {				
		return recGet(target, root);		
	}

	private T recGet(T target, BSTNode<T> node) {				
																
		if(node == null)										
			return null;										
		else if(comp.compare(target, node.getInfo()) < 0)		
			return recGet(target, node.getLeft());				
		else if(comp.compare(target, node.getInfo()) > 0)		
			return recGet(target, node.getRight());				
		else
			return node.getInfo();									
	}

	public boolean remove(T target) {			
		root = recRemove(target, root);			
		return found;							
	}

	private BSTNode<T> recRemove(T target, BSTNode<T> node) {
		if(node == null)												
			found = false;										 
		if(comp.compare(target, node.getInfo()) < 0)		
			node.setLeft(recRemove(target, node.getLeft()));	
		else if(comp.compare(target, node.getInfo()) > 0)		
			node.setRight(recRemove(target, node.getRight()));	
		else {								
			node = nodeRemove(node);							
			found = true;							
		}
		return node;			
	}

	private BSTNode<T> nodeRemove(BSTNode<T> node) {	
		T data;
		if(node.getLeft() == null)							
			return node.getRight();							
		else if(node.getRight() == null)					
			return node.getLeft();								
		else {												
			data = getPredecessor(node.getLeft());			
			node.setInfo(data);								
			node.setLeft(recRemove(data, node.getLeft()));	
			return node;
		}
	}

	private T getPredecessor(BSTNode<T> subtree) {		
		BSTNode<T> temp = subtree;						
		while(temp.getRight() != null)
			temp = temp.getRight();
		return temp.getInfo();
	}

	public boolean ifFull() { 		
		return false;
	}

	public boolean isEmpty() {
		return (root == null);
	}

	
	public int size() {				
		return recSize(root);
	}

	private int recSize(BSTNode<T> node) {		
		if(node == null)
			return 0;
		else
			return 1 + recSize(node.getLeft()) + recSize(node.getRight());
	}

	
	public T min() {			
		if(isEmpty())			
			return null;
		else {
			BSTNode<T> node = root;
			while(node.getLeft() != null) {
				node = node.getLeft();
			}
			return node.getInfo();
		}
	}

	
	public T max() {			
		if(isEmpty())			
			return null;
		else {
			BSTNode<T> node = root;
			while(node.getRight() != null) {
				node = node.getRight();
			}
			return node.getInfo();
		}
	}

	
	public BSTNode<T> sortedArrayToBST(T[] arr, int startIndex, int endIndex) {
		
		if(startIndex > endIndex)
			return null;
		int mid = (startIndex + endIndex)/2;
		BSTNode<T> node = new BSTNode<T>(arr[mid]);
		node.setLeft(sortedArrayToBST(arr, startIndex, mid-1));
		node.setRight(sortedArrayToBST(arr, startIndex, mid-1));
		return node;
	}
}
